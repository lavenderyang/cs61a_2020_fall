test = {
  'name': 'default',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> True
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
